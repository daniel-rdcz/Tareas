# Actividad 1.1 Implementación de la técnica de programación "divide y vencerás"

## Uso

Ejecutar el archivo ordena.exe dentro de la carpeta output, si se desea realizar pruebas editar el archivo de texto dentro de la misma carpeta, el primer renglón indicara lo largo del vector mientras que el resto de renglones serán los valores del mismo.